# Conquista del Mondo – app Android

Il gioco (cartella `www/`) è già impacchettato come app Android con Capacitor.
L'APK si compila da solo su GitHub, non serve installare nulla sul PC.

## Come ottenere l'APK

1. Crea un account su github.com (gratis) e un nuovo repository (anche privato).
2. Carica tutto il contenuto di questa cartella nel repository
   (pulsante "Add file" → "Upload files"; tieni anche la cartella nascosta `.github`).
3. Vai nella scheda **Actions**: parte da solo il lavoro "Build APK"
   (se non parte, aprilo e premi "Run workflow"). Dura circa 5–10 minuti.
4. A fine lavoro apri l'esecuzione e scarica **conquista-del-mondo-apk** in fondo
   alla pagina: è uno zip che contiene `app-debug.apk`.
5. Sul telefono copia l'APK, aprilo e consenti l'installazione da fonti sconosciute.

## Aggiornare il gioco

Sostituisci `www/index.html` nel repository: la build riparte e produce un nuovo APK.

## Note

- L'APK è "debug": si installa e funziona normalmente, ma non è firmato per il Play Store.
  Per pubblicarlo sul Play Store serve una build "release" firmata (posso preparartela).
- Il salvataggio della partita usa la memoria dell'app e funziona.
