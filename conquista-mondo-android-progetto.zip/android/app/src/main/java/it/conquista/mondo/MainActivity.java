package it.conquista.mondo;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
