import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'it.conquista.mondo',
  appName: 'Conquista del Mondo',
  webDir: 'www'
};

export default config;
